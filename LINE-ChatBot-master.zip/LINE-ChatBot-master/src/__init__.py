__author__ = "snoww0lf@Noobs1337"
__copyright__ = "Copyright (C) 2015 snoww0lf"
__license__ = "MIT License"